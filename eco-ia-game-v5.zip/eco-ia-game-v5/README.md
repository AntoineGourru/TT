# Calcul sous pression

Prototype de jeu web court pour une activité de vulgarisation sur les usages et les impacts environnementaux de l'IA.

## Lancer le jeu

Le jeu fonctionne directement en ouvrant `index.html` dans un navigateur moderne.

Pour le servir localement, depuis ce dossier :

```bash
python3 -m http.server 8080
```

Puis ouvrir `http://localhost:8080`.

## Règles actuelles

- 5 questions, une par niveau de difficulté.
- 2 min 30 de temps global.
- Une banque de 40 questions est incluse dans `questions.js`.
- Le bouton IA propose immédiatement une réponse.
- Chaque appel à l'IA a 1 chance sur 3 de proposer une mauvaise réponse plausible.
- La planète perd une ressource cachée à chaque appel.
- Au 3e appel à l'IA, la planète entre en surcharge et la partie s'arrête.
- Le coût caché et la probabilité d'erreur sont révélés à la fin.

## Modifier les questions

Les questions sont dans `questions.js`. Chaque objet suit ce format :

```js
{
  level: 3,
  text: "Énoncé...",
  answer: 42,
  unit: "kg",
  wrong: [38, 40, 48],
  hint: "Petit indice facultatif."
}
```

Pour une réponse décimale nécessitant une tolérance particulière :

```js
{
  answer: 3.333333,
  tolerance: 0.03
}
```

## Réglages principaux

En haut de `app.js` :

- `TOTAL_TIME = 150` : temps total en secondes.
- `MAX_AI_CALLS = 4` : nombre d'appels avant surcharge.
- `AI_ERROR_PROBABILITY = 1 / 3` : probabilité d'erreur de l'IA.

## Pour une version avec serveur

Cette V1 n'a volontairement aucun backend. Pour une banque de plusieurs centaines de questions, des statistiques de classe ou plusieurs niveaux par âge, on peut ensuite ajouter un petit backend Node/Express ou Python/FastAPI avec une base SQLite/PostgreSQL.


## V2 visuelle
La planète utilise désormais une illustration SVG animée avec des états progressifs : végétation, nuages, smog, sécheresse, points chauds et fissures. La logique du jeu est inchangée.


## V3 - planète optimisée

La planète utilise désormais quatre images pré-rendues de la Terre, centrées sur l'Europe et l'Afrique. Les transitions se font uniquement par fondu d'opacité. Les filtres SVG, flous animés et animations permanentes de la V2 ont été supprimés pour améliorer la fluidité.

## V4 - viewport, chrono et dégradation

- L'écran de jeu tient désormais dans la hauteur du navigateur sur ordinateur, sans défilement.
- Le chrono est placé dans la colonne de droite, en grand, avec une barre qui se vide. Il passe en orange sous 45 secondes puis en rouge sous 15 secondes.
- Les états 1 à 3 de la Terre sont plus contrastés. La végétation sèche, les océans s'assombrissent, un voile brun apparaît, puis des zones chaudes et des fissures deviennent visibles au dernier état avant surcharge.
- Ces dégradations restent pré-rendues dans les PNG afin de ne pas réintroduire les filtres et animations coûteux de la V2.


## Ajustements V5

- La planète explose désormais au 3e appel à l’IA.
- Le chrono déclenche des bips de plus en plus rapprochés et aigus à mesure que le temps baisse.
- Sous 15 secondes, une vignette visuelle renforce la pression.
- La planète est plus grande et ses deux premiers états de dégradation sont plus contrastés.
- Un résultat de 4/5 ou 5/5 déclenche un écran de réussite et une courte célébration.
