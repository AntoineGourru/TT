(() => {
  const TOTAL_TIME = 150;
  const MAX_AI_CALLS = 3;
  const AI_ERROR_PROBABILITY = 1 / 3;
  const TOTAL_QUESTIONS = 5;

  const $ = (id) => document.getElementById(id);
  const screens = ["introScreen", "gameScreen", "resultScreen", "teacherScreen"];

  const state = {
    questions: [],
    index: 0,
    correct: 0,
    aiCalls: 0,
    answered: false,
    remaining: TOTAL_TIME,
    timerId: null,
    exploded: false,
    sound: true,
    startedAt: 0,
    lastStressSecond: null,
  };

  const audioCtx = () => {
    if (!state.sound) return null;
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return null;
    if (!window.__gameAudio) window.__gameAudio = new Ctx();
    return window.__gameAudio;
  };

  function beep(freq = 440, duration = 0.08, type = "sine", gain = 0.035) {
    const ctx = audioCtx();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.value = gain;
    osc.connect(g); g.connect(ctx.destination);
    osc.start();
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
    osc.stop(ctx.currentTime + duration);
  }

  function showScreen(id) {
    screens.forEach((s) => $(s).classList.toggle("active", s === id));
    document.body.classList.toggle("game-active", id === "gameScreen");
    if (id !== "gameScreen") {
      document.body.classList.remove("time-warning", "time-danger");
    }
    window.scrollTo({ top: 0, behavior: id === "gameScreen" ? "auto" : "smooth" });
  }

  function shuffle(arr) {
    return [...arr].sort(() => Math.random() - 0.5);
  }

  function chooseQuestions() {
    return [1, 2, 3, 4, 5].map((level) => {
      const pool = window.QUESTIONS.filter((q) => q.level === level);
      return pool[Math.floor(Math.random() * pool.length)];
    });
  }

  function resetGame() {
    clearInterval(state.timerId);
    state.questions = chooseQuestions();
    state.index = 0;
    state.correct = 0;
    state.aiCalls = 0;
    state.answered = false;
    state.remaining = TOTAL_TIME;
    state.exploded = false;
    state.startedAt = Date.now();
    state.lastStressSecond = null;
    $("planetWrap").dataset.planetState = "0";
    $("planetPanel").dataset.planetState = "0";
    $("statusText").textContent = "Système en ligne";
    $("achievement").hidden = true;
    $("celebration").classList.remove("active");
    $("celebration").replaceChildren();
    $("explosionOverlay").classList.remove("active");
    $("explosionOverlay").setAttribute("aria-hidden", "true");
    renderQuestion();
    updateTimer();
  }

  function startGame() {
    resetGame();
    const ctx = audioCtx();
    if (ctx && ctx.state === "suspended") ctx.resume();
    showScreen("gameScreen");
    beep(360, .045, "sine", .012);
    state.timerId = setInterval(() => {
      state.remaining -= 1;
      updateTimer();
      if (state.remaining <= 0) finishGame("time");
    }, 1000);
    setTimeout(() => $("answerInput").focus(), 300);
  }

  function renderQuestion() {
    const q = state.questions[state.index];
    state.answered = false;
    $("questionNumber").textContent = state.index + 1;
    $("difficultyLabel").textContent = `Niveau ${q.level}`;
    $("questionText").textContent = q.text;
    $("questionHint").textContent = q.hint || "";
    $("answerUnit").textContent = q.unit || "";
    $("answerInput").value = "";
    $("answerInput").disabled = false;
    $("feedback").textContent = "";
    $("feedback").className = "feedback";
    $("aiMessage").textContent = "Besoin d’un coup de pouce ? L’IA peut calculer à ta place.";
    $("aiBtn").disabled = false;
    $("progressBar").style.width = `${((state.index + 1) / TOTAL_QUESTIONS) * 100}%`;
  }

  function parseAnswer(raw) {
    const cleaned = raw.trim().replace(/\s/g, "").replace(",", ".");
    if (!cleaned) return NaN;
    return Number(cleaned);
  }

  function isCorrect(value, q) {
    const tolerance = q.tolerance ?? Math.max(0.001, Math.abs(q.answer) * 0.0005);
    return Math.abs(value - q.answer) <= tolerance;
  }

  function submitAnswer(event) {
    event.preventDefault();
    if (state.answered || state.exploded) return;
    const q = state.questions[state.index];
    const value = parseAnswer($("answerInput").value);

    if (!Number.isFinite(value)) {
      $("feedback").textContent = "Entre un nombre avant de valider.";
      $("feedback").className = "feedback no";
      beep(190, .08, "square", .025);
      return;
    }

    state.answered = true;
    $("answerInput").disabled = true;
    $("aiBtn").disabled = true;

    if (isCorrect(value, q)) {
      state.correct += 1;
      $("feedback").textContent = "Correct. Question suivante...";
      $("feedback").className = "feedback ok";
      beep(650, .07, "sine", .03); setTimeout(() => beep(820, .09, "sine", .025), 70);
    } else {
      $("feedback").textContent = `Pas tout à fait. La réponse était ${formatNumber(q.answer)} ${q.unit || ""}.`;
      $("feedback").className = "feedback no";
      beep(180, .13, "triangle", .028);
    }

    setTimeout(nextQuestion, 900);
  }

  function nextQuestion() {
    if (state.exploded) return;
    if (state.index >= TOTAL_QUESTIONS - 1) {
      finishGame("complete");
      return;
    }
    state.index += 1;
    renderQuestion();
    $("answerInput").focus();
  }

  function formatNumber(n) {
    if (Number.isInteger(n)) return String(n);
    return String(Math.round(n * 100) / 100).replace(".", ",");
  }

  function useAI() {
    if (state.answered || state.exploded || $("aiBtn").disabled) return;
    const q = state.questions[state.index];
    state.aiCalls += 1;
    $("aiBtn").disabled = true;
    $("aiMessage").textContent = "Calcul en cours...";
    beep(410, .06, "sine", .02);

    updatePlanet();

    if (state.aiCalls >= MAX_AI_CALLS) {
      setTimeout(triggerExplosion, 720);
      return;
    }

    setTimeout(() => {
      const wrong = Math.random() < AI_ERROR_PROBABILITY;
      const proposed = wrong ? shuffle(q.wrong)[0] : q.answer;
      $("aiMessage").textContent = `L’IA propose : ${formatNumber(proposed)} ${q.unit || ""}. À toi de décider si tu lui fais confiance.`;
      $("answerInput").value = formatNumber(proposed);
      $("answerInput").focus();
      beep(wrong ? 330 : 520, .08, "sine", .022);
    }, 520);
  }

  function updatePlanet() {
    const visibleState = Math.min(state.aiCalls, 3);
    const panel = $("planetPanel");
    const planet = $("planetWrap");
    planet.dataset.planetState = String(visibleState);
    panel.dataset.planetState = String(visibleState);

    // Le coût reste volontairement implicite pendant la partie : seule la planète change.
    $("statusText").textContent = "Système en ligne";

    panel.classList.remove("shake", "planet-impact");
    void panel.offsetWidth;
    panel.classList.add("planet-impact");
    if (visibleState >= 2) panel.classList.add("shake");
    setTimeout(() => panel.classList.remove("planet-impact"), 760);
  }

  function triggerExplosion() {
    if (state.exploded) return;
    state.exploded = true;
    clearInterval(state.timerId);
    $("explosionOverlay").classList.add("active");
    $("explosionOverlay").setAttribute("aria-hidden", "false");

    const ctx = audioCtx();
    if (ctx) {
      [90, 70, 50].forEach((freq, i) => setTimeout(() => beep(freq, .55, "sawtooth", .05), i * 90));
    }

    setTimeout(() => {
      $("explosionOverlay").classList.remove("active");
      finishGame("exploded");
    }, 2000);
  }

  function playStressTick() {
    if (!state.sound || state.remaining <= 0 || state.exploded) return;

    const r = state.remaining;
    if (r === TOTAL_TIME) return;
    let cadence = 10;
    let freq = 315;
    let gain = .011;

    if (r <= 90) { cadence = 7; freq = 340; gain = .012; }
    if (r <= 60) { cadence = 5; freq = 375; gain = .014; }
    if (r <= 45) { cadence = 3; freq = 430; gain = .016; }
    if (r <= 30) { cadence = 2; freq = 500; gain = .019; }
    if (r <= 15) { cadence = 1; freq = 590 + (15 - r) * 18; gain = .024; }

    if (r % cadence !== 0 || state.lastStressSecond === r) return;
    state.lastStressSecond = r;
    beep(freq, r <= 15 ? .07 : .045, r <= 30 ? "square" : "sine", gain);
    if (r <= 7) setTimeout(() => beep(freq + 90, .045, "square", gain * .72), 105);
  }

  function updateTimer() {
    const m = Math.floor(state.remaining / 60);
    const s = state.remaining % 60;
    $("timer").textContent = `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
    const warning = state.remaining <= 45 && state.remaining > 15;
    const danger = state.remaining <= 15;
    $("timer").classList.toggle("warning", warning);
    $("timer").classList.toggle("danger", danger);
    $("timerPanel").classList.toggle("warning", warning);
    $("timerPanel").classList.toggle("danger", danger);
    document.body.classList.toggle("time-warning", warning);
    document.body.classList.toggle("time-danger", danger);
    $("timerBar").style.width = `${Math.max(0, state.remaining / TOTAL_TIME) * 100}%`;
    playStressTick();
  }

  function launchCelebration(perfect) {
    const layer = $("celebration");
    layer.replaceChildren();
    const count = perfect ? 34 : 24;
    for (let i = 0; i < count; i += 1) {
      const piece = document.createElement("i");
      piece.style.setProperty("--x", `${8 + Math.random() * 84}vw`);
      piece.style.setProperty("--delay", `${Math.random() * .55}s`);
      piece.style.setProperty("--drift", `${-70 + Math.random() * 140}px`);
      piece.style.setProperty("--spin", `${180 + Math.random() * 540}deg`);
      piece.className = `confetti-piece c${i % 4}`;
      layer.appendChild(piece);
    }
    layer.classList.remove("active");
    void layer.offsetWidth;
    layer.classList.add("active");
    setTimeout(() => layer.classList.remove("active"), 2800);

    beep(610, .08, "sine", .024);
    setTimeout(() => beep(770, .09, "sine", .025), 95);
    setTimeout(() => beep(980, .12, "sine", .022), 205);
  }

  function finishGame(reason) {
    clearInterval(state.timerId);
    const completed = reason === "complete";
    const exploded = reason === "exploded";
    const highScore = !exploded && state.correct >= 4;
    const perfect = highScore && state.correct === 5;

    $("resultEyebrow").textContent = exploded ? "Incident" : highScore ? "Performance" : completed ? "Défi terminé" : "Temps écoulé";
    $("resultTitle").textContent = exploded ? "La planète a lâché." : perfect ? "Sans faute." : highScore ? "Mission réussie." : completed ? "Tu es arrivé au bout." : "Le chrono a gagné.";

    if (exploded) {
      $("resultLead").textContent = "Quelque chose semblait se dégrader à chaque appel. Ce n’était pas seulement décoratif.";
    } else if (state.aiCalls === 0) {
      $("resultLead").textContent = "Tu as terminé sans solliciter l’assistant. Compare maintenant ta stratégie avec celle d’autres joueurs.";
    } else {
      $("resultLead").textContent = "Tu as jonglé entre calcul personnel et assistance. Le résultat raconte aussi comment tu as utilisé l’IA.";
    }

    $("statCorrect").textContent = `${state.correct}/5`;
    $("statAI").textContent = state.aiCalls;
    $("statTime").textContent = formatClock(Math.max(0, state.remaining));

    const achievement = $("achievement");
    achievement.hidden = !highScore;
    if (highScore) {
      $("achievementTitle").textContent = perfect ? "5 sur 5. Aucun faux pas." : "Moins de deux erreurs.";
      $("achievementText").textContent = perfect
        ? "Tu as gardé le contrôle malgré le chrono. Très propre."
        : "4 bonnes réponses sur 5 sous pression. Tu débloques le niveau maîtrise.";
    }

    const costSentence = state.aiCalls === 0
      ? "Dans cette partie, chaque appel à l’IA aurait retiré une ressource cachée à la planète. Tu n’en as utilisé aucun."
      : `Dans cette partie, chaque appel à l’IA retirait une ressource cachée à la planète. Tu as utilisé l’IA ${state.aiCalls} fois.`;
    const riskSentence = " Chaque réponse de l’IA avait aussi 1 chance sur 3 d’être fausse, même lorsqu’elle semblait crédible.";
    $("revealText").textContent = costSentence + riskSentence;

    showScreen("resultScreen");
    if (highScore) setTimeout(() => launchCelebration(perfect), 180);
  }

  function formatClock(seconds) {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }

  $("startBtn").addEventListener("click", startGame);
  $("answerForm").addEventListener("submit", submitAnswer);
  $("aiBtn").addEventListener("click", useAI);
  $("replayBtn").addEventListener("click", startGame);
  $("teacherBtn").addEventListener("click", () => showScreen("teacherScreen"));
  $("backToIntroBtn").addEventListener("click", () => showScreen("introScreen"));
  $("soundBtn").addEventListener("click", () => {
    state.sound = !state.sound;
    $("soundBtn").textContent = state.sound ? "SON" : "MUET";
    if (state.sound) beep(520, .06, "sine", .02);
  });
})();
