window.QUESTIONS = [
  // Niveau 1
  { level: 1, text: "Une boîte contient 8 rangées de 6 feutres. Combien y a-t-il de feutres ?", answer: 48, unit: "feutres", wrong: [42, 46, 54], hint: "Une seule opération suffit." },
  { level: 1, text: "Un bus transporte 36 élèves. 9 descendent. Combien restent dans le bus ?", answer: 27, unit: "élèves", wrong: [25, 29, 45], hint: "Une seule opération suffit." },
  { level: 1, text: "Un paquet de 5 cahiers coûte 15 €. Combien coûte un cahier ?", answer: 3, unit: "€", wrong: [2.5, 4, 5], hint: "Cherche le prix d'une unité." },
  { level: 1, text: "Une bouteille contient 1,5 L. On en boit 0,4 L. Combien reste-t-il ?", answer: 1.1, unit: "L", wrong: [0.9, 1.2, 1.9], hint: "Tu peux écrire les décimales avec une virgule." },
  { level: 1, text: "Un film commence à 14 h 20 et dure 40 minutes. À quelle heure finit-il ?", answer: 15, unit: "h", wrong: [14.6, 15.1, 15.2], hint: "Réponds sous forme d'heure décimale entière ici." },
  { level: 1, text: "Un rectangle mesure 7 cm de long et 4 cm de large. Quelle est son aire ?", answer: 28, unit: "cm²", wrong: [22, 24, 35], hint: "Aire d'un rectangle = longueur × largeur." },
  { level: 1, text: "Sur 20 questions, Léa en réussit 15. Quel pourcentage a-t-elle réussi ?", answer: 75, unit: "%", wrong: [70, 80, 85], hint: "Ramène la fraction sur 100." },
  { level: 1, text: "Trois amis se partagent 42 cartes à parts égales. Combien chacun en reçoit-il ?", answer: 14, unit: "cartes", wrong: [12, 13, 16], hint: "Partage en parts égales." },

  // Niveau 2
  { level: 2, text: "Un t-shirt à 40 € bénéficie d'une réduction de 25 %. Quel est son nouveau prix ?", answer: 30, unit: "€", wrong: [25, 28, 32], hint: "Calcule d'abord le montant de la réduction." },
  { level: 2, text: "Une classe de 28 élèves forme des groupes de 4. Chaque groupe reçoit 3 feuilles. Combien faut-il de feuilles ?", answer: 21, unit: "feuilles", wrong: [18, 24, 84], hint: "Trouve d'abord le nombre de groupes." },
  { level: 2, text: "Un cycliste parcourt 18 km le matin et 27 km l'après-midi. Il roule en moyenne à 15 km/h. Combien d'heures a-t-il roulé ?", answer: 3, unit: "h", wrong: [2.5, 3.5, 4], hint: "Distance totale puis temps = distance / vitesse." },
  { level: 2, text: "Une recette pour 4 personnes demande 300 g de farine. Combien faut-il de farine pour 10 personnes ?", answer: 750, unit: "g", wrong: [600, 700, 900], hint: "Utilise une proportion." },
  { level: 2, text: "Un réservoir de 80 L est rempli aux trois quarts. Combien contient-il de litres ?", answer: 60, unit: "L", wrong: [55, 64, 70], hint: "Trois quarts = 3/4." },
  { level: 2, text: "Une place coûte 12 €. Pour 7 places, on utilise un bon de réduction de 14 €. Quel est le total payé ?", answer: 70, unit: "€", wrong: [68, 72, 84], hint: "Calcule le prix avant réduction." },
  { level: 2, text: "Un fichier de 240 Mo est téléchargé à 30 Mo par seconde. Combien de secondes faut-il ?", answer: 8, unit: "s", wrong: [6, 10, 12], hint: "Temps = quantité / débit." },
  { level: 2, text: "Un jardin carré a un périmètre de 36 m. Quelle est son aire ?", answer: 81, unit: "m²", wrong: [72, 90, 1296], hint: "Trouve d'abord la longueur d'un côté." },

  // Niveau 3
  { level: 3, text: "Un train de 180 places est rempli à 70 %. À la gare suivante, 18 passagers descendent. Combien de passagers restent ?", answer: 108, unit: "passagers", wrong: [100, 112, 126], hint: "Calcule d'abord 70 % de 180." },
  { level: 3, text: "Un abonnement coûte 18 € par mois plus 0,05 € par minute. Pour 240 minutes, quel est le prix total ?", answer: 30, unit: "€", wrong: [28, 32, 42], hint: "Additionne la partie fixe et la partie variable." },
  { level: 3, text: "Une cuve contient 120 L. On retire 15 %, puis on ajoute 12 L. Combien contient-elle ensuite ?", answer: 114, unit: "L", wrong: [102, 108, 117], hint: "Les 15 % portent sur les 120 L initiaux." },
  { level: 3, text: "Un rectangle a une aire de 96 cm² et une largeur de 8 cm. On augmente sa longueur de 25 %. Quelle est la nouvelle aire ?", answer: 120, unit: "cm²", wrong: [112, 124, 144], hint: "Trouve d'abord la longueur initiale." },
  { level: 3, text: "Un article passe de 50 € à 44 €. Quel est le pourcentage de réduction ?", answer: 12, unit: "%", wrong: [10, 14, 16], hint: "Compare la baisse au prix de départ." },
  { level: 3, text: "Une voiture consomme 6 L pour 100 km. Combien consomme-t-elle pour 350 km ?", answer: 21, unit: "L", wrong: [18, 20, 24], hint: "Utilise une proportion." },
  { level: 3, text: "Un sac contient 5 boules rouges, 3 bleues et 2 vertes. Quelle est la probabilité, en %, de tirer une boule bleue ?", answer: 30, unit: "%", wrong: [20, 25, 33], hint: "Nombre de cas favorables / nombre total." },
  { level: 3, text: "Une somme augmente de 20 %, puis diminue de 20 %. En partant de 100 €, combien reste-t-il ?", answer: 96, unit: "€", wrong: [92, 100, 104], hint: "Les deux pourcentages ne s'appliquent pas à la même base." },

  // Niveau 4
  { level: 4, text: "Un ordinateur consomme 65 W pendant 6 h par jour. Sur 20 jours, combien consomme-t-il d'énergie en kWh ?", answer: 7.8, unit: "kWh", wrong: [6.5, 7.2, 8.4], hint: "Énergie = puissance × durée, puis convertis W en kW." },
  { level: 4, text: "Un produit coûte 80 € HT. On applique 20 % de TVA puis une remise de 10 % sur le prix TTC. Quel est le prix final ?", answer: 86.4, unit: "€", wrong: [84, 88, 90.4], hint: "Applique les changements successivement." },
  { level: 4, text: "Une ville de 24 000 habitants augmente de 5 %, puis perd 840 habitants. Quelle est sa nouvelle population ?", answer: 24360, unit: "habitants", wrong: [24160, 24400, 25200], hint: "Calcule l'augmentation avant la baisse." },
  { level: 4, text: "Une pompe remplit 18 L par minute. Une fuite vide 3 L par minute. Combien de minutes faut-il pour remplir 225 L ?", answer: 15, unit: "min", wrong: [12.5, 18, 25], hint: "Cherche le débit net." },
  { level: 4, text: "Un trajet de 180 km est effectué à 60 km/h à l'aller et à 90 km/h au retour. Combien d'heures dure le trajet total ?", answer: 5, unit: "h", wrong: [4, 4.5, 4.8], hint: "Calcule séparément les deux durées." },
  { level: 4, text: "Une batterie de 60 Wh alimente un appareil de 8 W, mais 20 % de l'énergie est perdue. Combien d'heures peut-il fonctionner ?", answer: 6, unit: "h", wrong: [5, 6.4, 7.5], hint: "Seule 80 % de l'énergie est réellement disponible." },
  { level: 4, text: "Une carte est à l'échelle 1:25 000. Deux points sont séparés de 7,2 cm sur la carte. Quelle est la distance réelle en km ?", answer: 1.8, unit: "km", wrong: [1.6, 2, 18], hint: "1 cm représente 25 000 cm dans la réalité." },
  { level: 4, text: "Le prix d'un objet augmente de 15 % puis baisse de 10 %. Il coûtait 200 €. Quel est son prix final ?", answer: 207, unit: "€", wrong: [200, 205, 210], hint: "Les variations sont successives." },

  // Niveau 5
  { level: 5, text: "Un serveur traite 480 requêtes en 3 minutes. Après optimisation, il en traite 25 % de plus dans le même temps. Combien traite-t-il de requêtes par seconde ?", answer: 3.3333333333, tolerance: 0.03, unit: "req/s", wrong: [3, 3.5, 4], hint: "Augmente d'abord le nombre de requêtes, puis convertis 3 minutes en secondes." },
  { level: 5, text: "Un réservoir est rempli à 40 %. On ajoute 36 L et il atteint alors 70 %. Quelle est sa capacité totale ?", answer: 120, unit: "L", wrong: [100, 126, 140], hint: "Les 36 L correspondent à 30 % de la capacité." },
  { level: 5, text: "Un train parcourt 120 km à 80 km/h puis 180 km à 120 km/h. Quelle est sa vitesse moyenne sur l'ensemble du trajet ?", answer: 100, unit: "km/h", wrong: [96, 102, 110], hint: "Vitesse moyenne = distance totale / durée totale." },
  { level: 5, text: "Une machine produit 500 pièces avec 4 % de défauts. Après réglage, elle produit 20 % de pièces en plus avec 2 % de défauts. Combien de pièces conformes produit-elle après réglage ?", answer: 588, unit: "pièces", wrong: [576, 590, 598], hint: "Calcule la nouvelle production puis retire 2 %." },
  { level: 5, text: "Une donnée est compressée de 35 %, puis le fichier compressé est encore réduit de 20 %. Un fichier initial faisait 500 Mo. Quelle est sa taille finale ?", answer: 260, unit: "Mo", wrong: [225, 250, 280], hint: "Applique les deux réductions successivement." },
  { level: 5, text: "Deux robinets remplissent une cuve. Le premier remplit 12 L/min et le second 8 L/min. Une fuite retire 5 L/min. Combien de temps faut-il pour remplir 360 L ?", answer: 24, unit: "min", wrong: [18, 20, 30], hint: "Additionne les entrées et retire la fuite." },
  { level: 5, text: "Une population de bactéries double toutes les 3 heures. Elle contient 250 bactéries au départ. Combien y en aura-t-il après 12 heures ?", answer: 4000, unit: "bactéries", wrong: [2000, 3000, 8000], hint: "Compte le nombre de doublements." },
  { level: 5, text: "Un forfait facture 12 € plus 0,08 € par Go. Une remise de 15 % s'applique sur la facture totale. Pour 100 Go, combien paie-t-on ?", answer: 17, unit: "€", wrong: [16, 18, 18.4], hint: "Calcule d'abord la facture avant remise." }
];
